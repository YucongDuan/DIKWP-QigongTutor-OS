from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

@dataclass
class LearnerProfile:
    learner_id: str
    age_group: str = "adult"
    experience_level: str = "beginner"
    goals: List[str] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    health_notes: List[str] = field(default_factory=list)
    practice_time_minutes: int = 15
    preferred_forms: List[str] = field(default_factory=list)
    safety_flags: List[str] = field(default_factory=list)

@dataclass
class CourseModule:
    module_id: str
    title: str
    form_family: str
    learning_focus: str
    recommended_minutes: int
    difficulty: int
    safety_level: str
    teacher_review_required: bool = False

@dataclass
class PracticeCase:
    case_id: str
    title: str
    learner: LearnerProfile
    modules: List[CourseModule]
    context: str = "home learning"

@dataclass
class SafetyDecision:
    decision: str
    reason: str
    safe_redirect: str
    flags: List[str] = field(default_factory=list)

@dataclass
class DikwRecord:
    object_id: str
    data: Dict[str, Any]
    information: Dict[str, Any]
    knowledge: Dict[str, Any]
    wisdom: Dict[str, Any]
    purpose: Dict[str, Any]
    reliability: Dict[str, Any]

@dataclass
class AnalysisReport:
    system: str
    version: str
    case_id: str
    learner_route: str
    safety_summary: Dict[str, int]
    module_count: int
    mean_practice_readiness: float
    red_flags: List[str]
    dikwp_ledger: List[DikwRecord]
    study_plan: List[Dict[str, Any]]
    teacher_pack: Dict[str, Any]
    misconception_map: List[Dict[str, str]]
    action_tickets: List[Dict[str, Any]]
    boundary_statement: str

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d
