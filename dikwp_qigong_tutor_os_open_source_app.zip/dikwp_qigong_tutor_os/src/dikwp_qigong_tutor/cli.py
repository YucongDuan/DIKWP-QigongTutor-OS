from __future__ import annotations
import argparse, json
from pathlib import Path
from .analyzer import load_case, analyze_case, write_outputs, guard_request
from .static_audit import run_static_audit

def main():
    ap = argparse.ArgumentParser(prog="qigong-tutor")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("analyze")
    a.add_argument("case")
    a.add_argument("--out", default="outputs/demo")
    g = sub.add_parser("guard")
    g.add_argument("text")
    sa = sub.add_parser("static-audit")
    sa.add_argument("path")
    sa.add_argument("--out")
    args = ap.parse_args()
    if args.cmd == "analyze":
        case=load_case(args.case)
        report=analyze_case(case)
        write_outputs(report, args.out)
        print(json.dumps({"case_id": report.case_id, "route": report.learner_route, "module_count": report.module_count, "mean_practice_readiness": report.mean_practice_readiness}, ensure_ascii=False, indent=2))
    elif args.cmd == "guard":
        print(json.dumps(guard_request(args.text).__dict__, ensure_ascii=False, indent=2))
    elif args.cmd == "static-audit":
        res=run_static_audit(args.path)
        if args.out:
            Path(args.out).parent.mkdir(parents=True, exist_ok=True)
            Path(args.out).write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(res, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
