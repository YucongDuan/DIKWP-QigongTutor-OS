# Optional Streamlit app placeholder. The offline HTML demo is the recommended interface.
try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

if st:
    st.title("DIKWP QigongTutor OS")
    st.write("Use the CLI or standalone index.html for the full offline demo.")
