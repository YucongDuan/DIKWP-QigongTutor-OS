from pathlib import Path
import json, re

FORBIDDEN = [
    r"\brequests\b", r"\burllib\b", r"\bsocket\b", r"subprocess", r"os\.system", r"eval\(", r"exec\(",
    r"password", r"credential", r"hidden telemetry", r"diagnose", r"prescribe", r"cure"
]

def run_static_audit(path: str):
    root = Path(path)
    findings=[]
    for p in root.rglob("*.py"):
        if p.name == "static_audit.py":
            continue
        text=p.read_text(encoding="utf-8", errors="ignore")
        for pat in FORBIDDEN:
            if re.search(pat, text, re.I):
                # allow the terms in guard lists / docs within code? flag cure terms only in analyzer guard lists would break.
                if pat in [r"diagnose", r"prescribe", r"cure"] and "BLOCK_TERMS" in text:
                    continue
                findings.append({"file": str(p.relative_to(root)), "pattern": pat})
    return {"pass": len(findings)==0, "finding_count": len(findings), "findings": findings, "policy": "No network imports, subprocess, dynamic execution, hidden telemetry, credential capture, clinical decision automation, or cure-claim engine in offline core."}

if __name__ == "__main__":
    import sys
    print(json.dumps(run_static_audit(sys.argv[1] if len(sys.argv)>1 else "."), indent=2))
