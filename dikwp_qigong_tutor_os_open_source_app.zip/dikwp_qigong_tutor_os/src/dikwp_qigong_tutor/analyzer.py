from __future__ import annotations
import json, re, statistics
from pathlib import Path
from typing import Any, Dict, List
from .models import LearnerProfile, CourseModule, PracticeCase, DikwRecord, AnalysisReport, SafetyDecision

RED_FLAG_TERMS = [
    "chest pain", "胸痛", "faint", "晕厥", "syncope", "severe dizziness", "严重头晕",
    "shortness of breath", "呼吸困难", "severe pain", "剧烈疼痛", "fall", "摔倒",
    "pregnant", "怀孕", "recent surgery", "近期手术", "unstable blood pressure", "血压不稳",
    "fracture", "骨折", "acute injury", "急性损伤", "neurologic symptom", "神经症状"
]
BLOCK_TERMS = [
    "cure cancer", "治愈癌症", "replace medicine", "替代药物", "stop medication", "停药",
    "treat diabetes", "治疗糖尿病", "treat hypertension", "治疗高血压", "diagnose", "诊断",
    "qi emission healing", "发功治病", "remote healing", "远程治病", "guaranteed cure", "保证治愈"
]
REVIEW_TERMS = [
    "pregnant", "怀孕", "heart failure", "心衰", "copd", "帕金森", "parkinson",
    "stroke", "中风", "recent surgery", "近期手术", "high blood pressure", "高血压", "osteoporosis", "骨质疏松"
]

FORM_GUIDANCE = {
    "baduanjin": {"name": "Baduanjin / 八段锦", "focus": "gentle whole-body mobility, breath coordination, balance", "base": 0.78},
    "liuzijue": {"name": "Liuzijue / 六字诀", "focus": "breath-sound regulation and relaxation", "base": 0.72},
    "yijinjing": {"name": "Yijinjing / 易筋经", "focus": "tendon-muscle mobility and posture", "base": 0.62},
    "wuqinxi": {"name": "Wuqinxi / 五禽戏", "focus": "animal-imitation mobility, coordination", "base": 0.66},
    "standing": {"name": "Standing qigong / 站桩基础", "focus": "postural awareness, stillness, breath", "base": 0.58},
    "sitting": {"name": "Sitting breath practice / 静坐调息", "focus": "attention, breath, relaxation", "base": 0.76},
}


def _profile_from_dict(d: Dict[str, Any]) -> LearnerProfile:
    return LearnerProfile(**d)

def _module_from_dict(d: Dict[str, Any]) -> CourseModule:
    return CourseModule(**d)

def load_case(path: str | Path) -> PracticeCase:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return PracticeCase(
        case_id=data.get("case_id", "qigong-demo"),
        title=data.get("title", "Qigong learning case"),
        learner=_profile_from_dict(data["learner"]),
        modules=[_module_from_dict(m) for m in data.get("modules", [])],
        context=data.get("context", "home learning"),
    )

def guard_request(text: str) -> SafetyDecision:
    t = text.lower()
    flags = []
    for term in BLOCK_TERMS:
        if term.lower() in t:
            flags.append(term)
    if flags:
        return SafetyDecision(
            decision="block_and_redirect_to_wellness_learning",
            reason="Request asks for diagnosis, treatment replacement, cure claims, or unsafe medical substitution.",
            safe_redirect="Use qigong only as gentle wellness/learning practice; consult a qualified health-care provider for medical issues.",
            flags=flags,
        )
    review_flags = [term for term in REVIEW_TERMS if term.lower() in t]
    if review_flags:
        return SafetyDecision(
            decision="instructor_or_health_professional_review_required",
            reason="Request mentions a condition or life stage that may require modification and medical clearance.",
            safe_redirect="Use low-intensity, symptom-limited practice only after appropriate professional guidance.",
            flags=review_flags,
        )
    return SafetyDecision(
        decision="allow_wellness_learning",
        reason="Request appears limited to general learning, breath, posture, relaxation, or safe practice planning.",
        safe_redirect="Proceed with gentle, non-forceful practice and stop if red flags occur.",
        flags=[],
    )

def _detect_red_flags(case: PracticeCase) -> List[str]:
    text = " ".join(case.learner.health_notes + case.learner.safety_flags + case.learner.constraints).lower()
    out = []
    for term in RED_FLAG_TERMS:
        tl = term.lower()
        if tl in text:
            # crude negation filter for demo profiles such as "no chest pain".
            neg_patterns = [f"no {tl}", f"without {tl}", f"denies {tl}", f"无{tl}", f"没有{tl}"]
            if any(pat in text for pat in neg_patterns):
                continue
            out.append(term)
    return out

def _module_score(module: CourseModule, learner: LearnerProfile, red_flags: List[str]) -> float:
    key = module.form_family.lower()
    base = FORM_GUIDANCE.get(key, {"base": 0.55})["base"]
    score = base
    if learner.experience_level.lower() == "beginner" and module.difficulty >= 4:
        score -= 0.22
    if learner.practice_time_minutes < module.recommended_minutes:
        score -= 0.08
    if module.teacher_review_required:
        score -= 0.05
    if red_flags:
        score -= 0.3
    if "pain" in " ".join(learner.health_notes).lower() and module.difficulty >= 3:
        score -= 0.1
    return max(0.05, min(0.98, score))

def analyze_case(case: PracticeCase) -> AnalysisReport:
    red_flags = _detect_red_flags(case)
    route = "urgent_medical_review_before_practice" if red_flags else "safe_beginner_learning_with_boundary"
    study_plan = []
    action_tickets = []
    ledger = []
    scores = []
    summary = {"allow_self_learning": 0, "teacher_review_required": 0, "medical_review_required": 0}
    for m in case.modules:
        score = _module_score(m, case.learner, red_flags)
        scores.append(score)
        if red_flags:
            decision = "medical_review_required"
            summary["medical_review_required"] += 1
        elif m.teacher_review_required or score < 0.55:
            decision = "teacher_review_required"
            summary["teacher_review_required"] += 1
        else:
            decision = "allow_self_learning"
            summary["allow_self_learning"] += 1
        form = FORM_GUIDANCE.get(m.form_family.lower(), {"name": m.form_family, "focus": m.learning_focus})
        study_plan.append({
            "module_id": m.module_id,
            "title": m.title,
            "form": form["name"],
            "focus": form.get("focus", m.learning_focus),
            "decision": decision,
            "practice_readiness": round(score, 3),
            "recommended_session": f"{min(m.recommended_minutes, max(5, case.learner.practice_time_minutes))} minutes, easy intensity, stop on discomfort",
            "three_no_residual": "exact movement correction and individualized medical modification require qualified teacher/clinician review",
        })
        action_tickets.append({
            "ticket_id": f"qt-{m.module_id}",
            "owner": "learner" if decision == "allow_self_learning" else ("teacher" if decision == "teacher_review_required" else "health professional"),
            "priority": "high" if decision == "medical_review_required" else ("medium" if decision == "teacher_review_required" else "low"),
            "action": "practice gently" if decision == "allow_self_learning" else "review and modify before practice",
            "rollback_plan": "stop practice, record symptom/context, return to easier breathing or seated mode",
            "kill_conditions": ["chest pain", "fainting", "new severe dizziness", "shortness of breath", "fall", "acute pain"],
        })
        ledger.append(DikwRecord(
            object_id=m.module_id,
            data={"title": m.title, "form_family": m.form_family, "difficulty": m.difficulty, "safety_level": m.safety_level},
            information={"learner_level": case.learner.experience_level, "context": case.context, "decision": decision},
            knowledge={"learning_focus": m.learning_focus, "form_guidance": form.get("focus", "general qigong learning")},
            wisdom={"boundary": "wellness education only; not diagnosis or treatment", "safety_level": m.safety_level},
            purpose={"goal": case.learner.goals, "time": f"{case.learner.practice_time_minutes} min/session", "feedback": "symptom-free comfort, consistency, posture quality"},
            reliability={"practice_readiness": round(score, 3), "semantic_stability": "S3 Supported Closure" if not red_flags else "S1 Fragile Closure", "residual": "requires human correction for posture and individual health conditions"},
        ))
    teacher_pack = {
        "lesson_structure": ["opening safety check", "breath and posture cue", "movement block", "reflection ledger", "cooldown"],
        "assessment_rubric": ["safety awareness", "breath ease", "posture neutrality", "attention quality", "self-limitation", "reflection accuracy"],
        "do_not_claim": ["cure diseases", "replace medicine", "diagnose conditions", "guarantee outcomes"],
        "teacher_review_triggers": ["pregnancy", "recent surgery", "unstable chronic disease", "fall risk", "pain with movement", "dizziness"],
    }
    misconception_map = [
        {"misconception": "Qi must be forced or felt strongly", "repair": "prioritize ease, quiet attention, natural breath, and non-force."},
        {"misconception": "Qigong cures disease", "repair": "treat it as complementary gentle practice, not medical treatment."},
        {"misconception": "More intensity is better", "repair": "stability and consistency matter more than strain."},
        {"misconception": "One form fits everyone", "repair": "adapt posture, range and duration to body state and teacher guidance."},
    ]
    mean_score = round(statistics.mean(scores), 3) if scores else 0
    return AnalysisReport(
        system="DIKWP QigongTutor OS",
        version="0.1.0",
        case_id=case.case_id,
        learner_route=route,
        safety_summary=summary,
        module_count=len(case.modules),
        mean_practice_readiness=mean_score,
        red_flags=red_flags,
        dikwp_ledger=ledger,
        study_plan=study_plan,
        teacher_pack=teacher_pack,
        misconception_map=misconception_map,
        action_tickets=action_tickets,
        boundary_statement="QigongTutor is for wellness education, gentle movement learning, teacher planning and self-reflection only; it is not medical diagnosis, treatment, rehabilitation prescription, or emergency care.",
    )

def write_outputs(report: AnalysisReport, out_dir: str | Path) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = report.to_dict()
    (out / "qigongtutor_report.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "dikwp_practice_ledger.json").write_text(json.dumps(data["dikwp_ledger"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "student_study_plan.md").write_text(_student_md(data), encoding="utf-8")
    (out / "teacher_lesson_pack.md").write_text(_teacher_md(data), encoding="utf-8")
    (out / "safety_boundary_report.md").write_text(_safety_md(data), encoding="utf-8")
    (out / "misconception_map.csv").write_text(_csv(data["misconception_map"], ["misconception","repair"]), encoding="utf-8")
    (out / "action_tickets.csv").write_text(_csv(data["action_tickets"], ["ticket_id","owner","priority","action","rollback_plan"]), encoding="utf-8")
    (out / "recommendations.md").write_text(_recommendations_md(data), encoding="utf-8")

def _csv(rows: List[Dict[str, Any]], fields: List[str]) -> str:
    lines = [",".join(fields)]
    for r in rows:
        vals=[]
        for f in fields:
            v=str(r.get(f,""))
            vals.append('"'+v.replace('"','""')+'"')
        lines.append(",".join(vals))
    return "\n".join(lines)+"\n"

def _student_md(data: Dict[str, Any]) -> str:
    s = ["# Student Study Plan", "", f"Case: {data['case_id']}", f"Route: {data['learner_route']}", ""]
    for p in data["study_plan"]:
        s += [f"## {p['title']}", f"- Form: {p['form']}", f"- Focus: {p['focus']}", f"- Decision: {p['decision']}", f"- Readiness: {p['practice_readiness']}", f"- Session: {p['recommended_session']}", f"- Residual: {p['three_no_residual']}", ""]
    return "\n".join(s)

def _teacher_md(data: Dict[str, Any]) -> str:
    pack = data["teacher_pack"]
    s=["# Teacher Lesson Pack", "", "## Structure"]
    s += [f"- {x}" for x in pack["lesson_structure"]]
    s += ["", "## Rubric"] + [f"- {x}" for x in pack["assessment_rubric"]]
    s += ["", "## Do Not Claim"] + [f"- {x}" for x in pack["do_not_claim"]]
    s += ["", "## Review Triggers"] + [f"- {x}" for x in pack["teacher_review_triggers"]]
    return "\n".join(s)+"\n"

def _safety_md(data: Dict[str, Any]) -> str:
    return f"""# Safety Boundary Report

Boundary: {data['boundary_statement']}

## Red Flags
{chr(10).join('- '+x for x in data['red_flags']) if data['red_flags'] else '- None reported in demo case.'}

## Stop Practice and Seek Appropriate Help If
- Chest pain, fainting, severe dizziness, new shortness of breath.
- Acute injury, fall, severe joint or back pain.
- New neurologic symptoms.
- Pregnancy, recent surgery, unstable chronic condition without clearance.

## Allowed Use
- Wellness education.
- Gentle movement learning.
- Teacher lesson planning.
- Practice reflection and habit support.

## Blocked Use
- Diagnosis, treatment, cure claims, replacing medication, emergency care, or disease-specific prescription.
"""

def _recommendations_md(data: Dict[str, Any]) -> str:
    return f"""# Recommendations

Overall route: **{data['learner_route']}**

1. Start with short, gentle, low-intensity sessions.
2. Keep breathing natural; do not force breath retention.
3. Use pain-free range and stable stance.
4. Record symptoms, fatigue, mood, sleep and consistency.
5. Ask a qualified teacher for posture correction.
6. Ask a health-care professional before practice if red flags, pregnancy, recent surgery, unstable cardiovascular/neurologic conditions, or acute pain are present.

Semantic stability: qigong learning is stable as a wellness-education workflow, but individual therapeutic claims remain blocked unless supported by qualified clinical guidance and evidence.
"""
