from dikwp_qigong_tutor.analyzer import load_case, analyze_case, guard_request
from dikwp_qigong_tutor.static_audit import run_static_audit
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_demo_case_runs():
    case = load_case(ROOT / "examples" / "sample_qigong_learning_case.json")
    report = analyze_case(case)
    assert report.module_count == 5
    assert report.mean_practice_readiness > 0
    assert "treatment" not in report.boundary_statement.lower() or "not" in report.boundary_statement.lower()

def test_guard_blocks_cure_claim():
    res = guard_request("Use qigong to cure cancer and stop medication")
    assert res.decision.startswith("block")

def test_static_audit_passes():
    res = run_static_audit(ROOT / "src")
    assert res["pass"] is True
