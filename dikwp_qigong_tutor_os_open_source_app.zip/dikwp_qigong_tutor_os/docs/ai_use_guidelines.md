# AI Use Guidelines

AI can help explain concepts, build study plans and produce reflection prompts. AI must not be used to generate cure claims, replace clinical care, or pressure learners into intense practice.

Allowed prompts:

- Explain Baduanjin as a gentle wellness practice.
- Build a beginner reflection log.
- Create a teacher safety checklist.

Blocked prompts:

- Cure my disease using qigong.
- Tell me to stop medication.
- Diagnose my symptoms.
- Generate breath retention for a heart patient.
