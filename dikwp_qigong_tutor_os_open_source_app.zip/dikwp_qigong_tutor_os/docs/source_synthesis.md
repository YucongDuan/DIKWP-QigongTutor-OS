# Source Synthesis

The system uses conservative public-health framing. Qigong is treated as a gentle mind-body wellness practice involving movement, breath and attention. Evidence for specific clinical outcomes varies by condition, and learners should not use it to postpone health-care evaluation.

The DIKWP design uses semantic compression, intention coupling, evidence ledger, residual queue and action boundary concepts from the DIKWP framework.
