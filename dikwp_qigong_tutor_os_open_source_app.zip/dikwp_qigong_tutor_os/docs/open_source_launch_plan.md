# Open Source Launch Plan

1. Publish repository as `DIKWP-QigongTutor-OS`.
2. Include README, NOTICE, CITATION, LICENSE, examples and standalone demo.
3. Release a short Chinese product brief.
4. Invite teachers, community health educators and movement educators to test.
5. Avoid disease-cure marketing.
6. Add new forms only with safety notes and teacher-review flags.
