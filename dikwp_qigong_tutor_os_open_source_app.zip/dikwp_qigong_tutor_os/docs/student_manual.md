# Student Manual

## How to use the system

1. Start with a learner profile.
2. Choose a gentle goal.
3. Read the safety boundary.
4. Practice short sessions.
5. Stop if red flags occur.
6. Record comfort, fatigue, breath ease and mood.
7. Ask a teacher for posture correction.

## Good signs

- Relaxed breathing.
- Stable stance.
- Mild warmth or relaxation without strain.
- Clearer attention.
- Better consistency.

## Stop signs

- Chest pain.
- Fainting.
- Severe dizziness.
- Shortness of breath.
- Acute pain.
- New neurologic symptoms.
- Fall or injury.
