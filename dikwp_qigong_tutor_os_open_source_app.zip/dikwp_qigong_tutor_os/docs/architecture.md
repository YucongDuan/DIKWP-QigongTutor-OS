# Architecture

The system has four layers.

## 1. Intake layer

The intake layer reads a learner profile and qigong course modules.

## 2. SemanticClosure layer

The system assumes that user goals, body condition and practice capacity are incomplete, imprecise and sometimes inconsistent. It separates primary anchors, residuals, teacher-review triggers and medical-review triggers.

## 3. DIKWP ledger layer

Every module is compiled into D/I/K/W/P/R. This prevents qigong learning from being reduced to posture imitation or health claims.

## 4. Output layer

The output layer produces student plans, teacher packs, safety reports, misconception repair maps and action tickets.
