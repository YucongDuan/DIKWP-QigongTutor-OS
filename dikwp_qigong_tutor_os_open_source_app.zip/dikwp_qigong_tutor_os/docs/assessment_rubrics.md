# Assessment Rubrics

## Student self-reflection rubric

- I practiced within a comfortable range.
- My breathing remained natural.
- I stopped or modified when discomfort appeared.
- I understood the difference between wellness practice and medical treatment.
- I recorded residual questions.

## Teacher observation rubric

- Movement safety.
- Alignment appropriateness.
- Breath ease.
- Attention stability.
- Respect for health boundaries.
- Ability to explain without mystification or cure claims.
