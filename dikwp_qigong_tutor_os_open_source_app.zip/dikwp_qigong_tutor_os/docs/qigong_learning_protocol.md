# Qigong Learning Protocol

## Beginner sequence

1. Orientation: what qigong is and is not.
2. Breath awareness without breath forcing.
3. Standing or seated posture with comfort.
4. Gentle movement block.
5. Cooldown and reflection.
6. Practice ledger update.

## Progression rule

Progression depends on comfort, consistency, posture quality and absence of red flags. It does not depend on intense sensation, mystical claims or strain.

## Forms supported

- Baduanjin / 八段锦
- Liuzijue / 六字诀
- Yijinjing / 易筋经
- Wuqinxi / 五禽戏
- Standing qigong / 站桩基础
- Sitting breath practice / 静坐调息

## Do not claim

- Qigong cures disease.
- Qigong replaces medication.
- Strong qi sensation is required.
- Breath retention is always beneficial.
- One form fits everyone.
