# Teacher Manual

## Lesson structure

- Safety check.
- Learner intention statement.
- Gentle warm-up.
- Movement or breath block.
- Teacher correction.
- Cooldown.
- Reflection ledger.

## Teacher review triggers

- Pregnancy.
- Recent surgery.
- Cardiovascular instability.
- Severe dizziness.
- Fall risk.
- Acute pain.
- Neurologic symptoms.
- Severe mental distress.

## Assessment dimensions

- Safety awareness.
- Breath ease.
- Posture neutrality.
- Smoothness.
- Attention quality.
- Self-limitation.
- Consistency.

## Teacher responsibility

Teachers should avoid disease-cure claims and should refer learners to qualified health-care professionals when medical symptoms or red flags appear.
