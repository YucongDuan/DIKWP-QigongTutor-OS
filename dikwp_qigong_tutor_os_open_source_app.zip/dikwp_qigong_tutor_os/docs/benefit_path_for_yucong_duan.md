# Benefit Path for Yucong Duan / DIKWP

This project can help DIKWP enter community wellness education, movement learning, senior education, school health education and AI-assisted teaching governance.

Open-source layer:

- CLI.
- HTML demo.
- Schema.
- Example case.
- Teacher pack.
- Safety guard.

Value layer:

- DIKWP QigongTutor certification.
- Community course template packs.
- Teacher training workshops.
- TrustPassport registry.
- Integration with health education and wellness platforms.
