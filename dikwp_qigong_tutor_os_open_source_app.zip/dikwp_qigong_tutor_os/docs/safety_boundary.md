# Safety Boundary

QigongTutor OS is not medical care. It does not diagnose, treat, prescribe, cure, manage emergencies or replace conventional care.

Qigong should not be used to postpone seeing a health-care provider for a medical problem. Learners with pregnancy, recent surgery, unstable chronic disease, severe dizziness, chest pain, shortness of breath, falls, acute injury or severe pain should seek appropriate professional guidance before practice.

All practice should be gentle, symptom-limited, non-forceful and reversible.
