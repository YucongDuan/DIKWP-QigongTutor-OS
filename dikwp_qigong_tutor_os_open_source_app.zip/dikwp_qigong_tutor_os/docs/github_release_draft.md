# GitHub Release Draft

DIKWP QigongTutor OS v0.1.0 is a wellness education and teaching governance system for qigong learning. It generates DIKWP learning ledgers, student study plans, teacher lesson packs, safety boundary reports, misconception maps and action tickets.

This release is offline-first and includes a standalone HTML demo.
