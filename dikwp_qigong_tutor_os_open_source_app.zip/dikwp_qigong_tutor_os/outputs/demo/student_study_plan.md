# Student Study Plan

Case: qigong-demo-001
Route: safe_beginner_learning_with_boundary

## Orientation: what qigong is and is not
- Form: Sitting breath practice / 静坐调息
- Focus: attention, breath, relaxation
- Decision: allow_self_learning
- Readiness: 0.76
- Session: 10 minutes, easy intensity, stop on discomfort
- Residual: exact movement correction and individualized medical modification require qualified teacher/clinician review

## Baduanjin foundation sequence
- Form: Baduanjin / 八段锦
- Focus: gentle whole-body mobility, breath coordination, balance
- Decision: allow_self_learning
- Readiness: 0.78
- Session: 15 minutes, easy intensity, stop on discomfort
- Residual: exact movement correction and individualized medical modification require qualified teacher/clinician review

## Standing alignment and balance basics
- Form: Standing qigong / 站桩基础
- Focus: postural awareness, stillness, breath
- Decision: teacher_review_required
- Readiness: 0.53
- Session: 10 minutes, easy intensity, stop on discomfort
- Residual: exact movement correction and individualized medical modification require qualified teacher/clinician review

## Liuzijue breath-sound introduction
- Form: Liuzijue / 六字诀
- Focus: breath-sound regulation and relaxation
- Decision: allow_self_learning
- Readiness: 0.72
- Session: 12 minutes, easy intensity, stop on discomfort
- Residual: exact movement correction and individualized medical modification require qualified teacher/clinician review

## Yijinjing mobility preview
- Form: Yijinjing / 易筋经
- Focus: tendon-muscle mobility and posture
- Decision: teacher_review_required
- Readiness: 0.17
- Session: 15 minutes, easy intensity, stop on discomfort
- Residual: exact movement correction and individualized medical modification require qualified teacher/clinician review
