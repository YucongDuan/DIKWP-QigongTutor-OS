# Recommendations

Overall route: **safe_beginner_learning_with_boundary**

1. Start with short, gentle, low-intensity sessions.
2. Keep breathing natural; do not force breath retention.
3. Use pain-free range and stable stance.
4. Record symptoms, fatigue, mood, sleep and consistency.
5. Ask a qualified teacher for posture correction.
6. Ask a health-care professional before practice if red flags, pregnancy, recent surgery, unstable cardiovascular/neurologic conditions, or acute pain are present.

Semantic stability: qigong learning is stable as a wellness-education workflow, but individual therapeutic claims remain blocked unless supported by qualified clinical guidance and evidence.
