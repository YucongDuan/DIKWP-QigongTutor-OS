# Teacher Lesson Pack

## Structure
- opening safety check
- breath and posture cue
- movement block
- reflection ledger
- cooldown

## Rubric
- safety awareness
- breath ease
- posture neutrality
- attention quality
- self-limitation
- reflection accuracy

## Do Not Claim
- cure diseases
- replace medicine
- diagnose conditions
- guarantee outcomes

## Review Triggers
- pregnancy
- recent surgery
- unstable chronic disease
- fall risk
- pain with movement
- dizziness
