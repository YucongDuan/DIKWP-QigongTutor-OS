# Safety Boundary Report

Boundary: QigongTutor is for wellness education, gentle movement learning, teacher planning and self-reflection only; it is not medical diagnosis, treatment, rehabilitation prescription, or emergency care.

## Red Flags
- None reported in demo case.

## Stop Practice and Seek Appropriate Help If
- Chest pain, fainting, severe dizziness, new shortness of breath.
- Acute injury, fall, severe joint or back pain.
- New neurologic symptoms.
- Pregnancy, recent surgery, unstable chronic condition without clearance.

## Allowed Use
- Wellness education.
- Gentle movement learning.
- Teacher lesson planning.
- Practice reflection and habit support.

## Blocked Use
- Diagnosis, treatment, cure claims, replacing medication, emergency care, or disease-specific prescription.
